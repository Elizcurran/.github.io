# Maricopa County Design System — Typography Specification

**For:** Americaneagle.com (WordPress / Gutenberg implementation)
**From:** Office of Communications — Web & Creative Strategy
**Expands:** Section 3 (Typography) of the Maricopa County Token Specification. Where this document and Section 3 differ, this document governs.
**Typefaces:** Poppins and Roboto (brand-mandated; not open to substitution)
**Status:** Draft for vendor review

---

## 1. Purpose

The Brand Standards Guide assigns Poppins to headlines and Roboto to subheadings, body, and links. That pairing is sound; this document defines the rules that make it perform on screen. The central requirement is not *which* typefaces — those are fixed — but *where each one is allowed to work*. Poppins is a geometric display face whose strength at large sizes becomes a legibility liability at small sizes; Roboto is a screen-optimized reading face. This specification confines each to the role it does well.

Sections 3 through 8 are implementation requirements and use "shall." Section 9 is the basis for acceptance. A general instruction to "use Poppins and Roboto" is not sufficient; the role split below is enforceable and will be checked against computed styles.

---

## 2. Typefaces and loading

| Typeface | Role | Weights used |
|---|---|---|
| **Poppins** | Display headings and short, prominent interactive labels | ExtraBold 800, Bold 700 |
| **Roboto** | Body, all reading text, form controls, small UI text | Regular 400, Medium 500, Bold 700 |

Requirements:

1. Both families **shall be self-hosted**. No font shall be requested from the Google Fonts CDN or any third-party origin. Both are openly licensed and redistributable; license files shall be retained in the repository.
2. `font-display: swap` shall be set on every `@font-face`.
3. Only the weights listed above shall be shipped. Do not load the full weight range; each unused weight is payload on every page.
4. Fonts shall be subset to the Latin range actually used, and the primary body weight (Roboto 400) and primary display weight (Poppins 800) **shall be `preload`ed** to reduce first-paint delay.
5. Sizing **shall use `rem`**, so browser zoom and OS/browser minimum-font-size settings scale the whole system. The viewport meta tag **shall not** contain `user-scalable=no` or `maximum-scale` (WCAG 1.4.4).

---

## 3. The role split — the governing rule

**Poppins shall not be used below 16px. Any text smaller than 16px shall be Roboto.**

Beyond that floor, the split is by *how the text is used*, because some text is read linearly even when it is large:

- **Poppins** is permitted only for: display headings (H1–H4), and short prominent interactive labels — buttons, tabs, primary navigation, accordion/section headers — at **16px and above**.
- **Roboto** shall be used for: body and paragraph text, lead paragraphs, form field labels, help/hint text, error and validation messages, breadcrumbs, captions, metadata, table cell text, and any UI text below 16px — **regardless of size**. These are read, not scanned as shapes, and Roboto is measurably faster to read and materially better for readers with dyslexia (Poppins's uniform, mirrored `b/d/p/q` and identical round forms slow differentiation).

Element-by-element mapping:

| Element | Typeface | Weight | Notes |
|---|---|---|---|
| H1 / page title | Poppins | ExtraBold 800 | |
| H2 / section | Poppins | ExtraBold 800 | |
| H3 / subsection | Poppins | Bold 700 | |
| H4 / minor heading | Poppins | Bold 700 | 16px floor |
| Button label | Poppins | Bold 700 | ≥16px required |
| Tab label | Poppins | Bold 700 | ≥16px required |
| Primary nav item | Poppins | Bold 700 | **≥16px required — see 3.1** |
| Accordion / disclosure header | Poppins | Bold 700 | ≥16px required |
| Eyebrow / overline | Roboto | Bold 700 | uppercase, tracked; read as label |
| Lead paragraph | Roboto | Regular 400 | |
| Body / paragraph | Roboto | Regular 400 | |
| List item | Roboto | Regular 400 | |
| Link (inline) | Roboto | Medium 500 | colour per Color Spec |
| Form field label | Roboto | Bold 700 | **Roboto even though prominent** |
| Help / hint text | Roboto | Regular 400 | |
| Error / validation | Roboto | Bold 700 | |
| Breadcrumb | Roboto | Regular/Medium | |
| Table header cell | Roboto | Bold 700 | |
| Table data cell | Roboto | Regular 400 | |
| Caption / metadata | Roboto | Regular 400 | |

### 3.1 Known correction

Current prototypes set primary navigation and some header nav at **15px Poppins**. This violates the 16px floor. Navigation set in Poppins **shall be raised to 16px**, or moved to Roboto. This is a required fix, not a preference.

---

## 4. Weight pairing

1. The primary hierarchy is **Poppins ExtraBold 800 headings against Roboto Regular 400 body**. This weight jump is what makes the pairing read as intentional; it shall be preserved rather than flattened toward middle weights.
2. **Poppins in weights 400 or 500 shall not be used for any text**, and never adjacent to body copy. Poppins's mid weights read as a slightly-wrong body font; this is the most common way the pairing degrades.
3. Emphasis within Roboto body copy shall use Roboto Bold 700, not a switch to Poppins.
4. Faux (synthesized) bold or italic shall not be used. If a weight is needed, it shall be a real shipped weight from Section 2.

---

## 5. Two type scales — content vs. application

Long-form reading and dense interface chrome have different optimal settings; a single scale serves neither well. Two scales shall be defined and applied by context.

### 5.1 Content scale — articles, service pages, long-form

| Role | Family / weight | Size | Line-height |
|---|---|---|---|
| H1 | Poppins 800 | clamp(30px → 40px) | 1.08 |
| H2 | Poppins 800 | 26px | 1.18 |
| H3 | Poppins 700 | 20px | 1.25 |
| H4 | Poppins 700 | 16px | 1.3 |
| Lead | Roboto 400 | 20px | 1.6 |
| Body | Roboto 400 | **18px** | 1.7 |
| Small / caption | Roboto 400 | 14px | 1.5 |
| Eyebrow | Roboto 700 | 14px, uppercase | 1.3 |

### 5.2 Application scale — portal, forms, dense UI

| Role | Family / weight | Size | Line-height |
|---|---|---|---|
| Page title | Poppins 800 | 30px | 1.1 |
| Section heading | Poppins 800 | 20px | 1.2 |
| Card / widget title | Poppins 700 | 18px | 1.25 |
| Button / tab / nav label | Poppins 700 | 16px | 1 |
| Body / UI text | Roboto 400 | **16px** | 1.6 |
| Form label | Roboto 700 | 16px | 1.4 |
| Help / hint | Roboto 400 | 14px | 1.5 |
| Meta / caption | Roboto 400 | 13–14px | 1.4 |

Body text shall never be set below 16px in either scale.

---

## 6. Letter-spacing (tracking)

1. **Roboto shall receive no tracking adjustment** at any size. It is drawn for its default spacing.
2. **Poppins shall be tracked tighter as it scales up**, or headlines read loose and gappy — a characteristic of geometric faces. Starting values:
   - 16–24px: `-0.01em`
   - 24–36px: `-0.015em`
   - 36px and above: `-0.02em`
3. Uppercase eyebrows/overlines (Roboto) shall be tracked **open**, approximately `+0.08em` to `+0.1em`.

---

## 7. Measure, line-height, and spacing

1. **Line length (measure):** body text shall be constrained to roughly **45–90 characters per line, targeting ~66**. On content pages this means a text column of about 680–720px; full-viewport-width paragraphs are not acceptable.
2. **Text spacing (WCAG 1.4.12):** content shall remain fully functional — no clipping, overlap, or lost text — when the user sets line height to 1.5× font size, spacing after paragraphs to 2× font size, letter spacing to 0.12em, and word spacing to 0.16em. Fixed-height text containers that would clip under these conditions are a defect.
3. Paragraph spacing shall be expressed as space *between* blocks (margin), not empty lines, and shall be at least 0.75× the body font size.

---

## 8. Fallback fonts and layout stability

Because Poppins and Roboto have different x-heights and metrics, an unstyled fallback swap can cause a visible reflow (cumulative layout shift). Each family shall declare a metric-adjusted fallback.

1. Each family shall have a fallback `@font-face` built over a local system font using `size-adjust`, `ascent-override`, and `descent-override` so the fallback occupies nearly the same space as the web font. Exact values shall be generated from the actual fonts (e.g., with a fallback-metrics generator) and verified, not guessed. Starting points to verify:
   - **Roboto** over Arial: `size-adjust` near 100% (metrics are close).
   - **Poppins** over a geometric fallback (Century Gothic / Trebuchet MS class): `size-adjust` will need to be **below 100%** because Poppins has a comparatively small x-height.
2. Declared stacks:
   ```css
   --font-display: 'Poppins', 'Poppins Fallback', 'Century Gothic', 'Trebuchet MS', sans-serif;
   --font-body:    'Roboto', 'Roboto Fallback', Arial, 'Helvetica Neue', sans-serif;
   ```
   where `'Poppins Fallback'` and `'Roboto Fallback'` are the metric-adjusted `@font-face` rules above.
3. Cumulative layout shift attributable to font swap shall be effectively zero in testing.

---

## 9. Acceptance criteria

Deliverables will be checked against the following. "Uses Poppins and Roboto" is not evidence of conformance.

1. **Computed font-family by role.** Spot-checked across templates: headings and prominent interactive labels compute to Poppins; body, form labels, help text, errors, breadcrumbs, captions, and table data compute to Roboto.
2. **16px floor.** No element with a computed font-size below 16px uses Poppins. (Automated check: query all text nodes; flag any `font-family: Poppins*` with computed size < 16px.)
3. **No middle-weight Poppins text.** No text block computes to Poppins 400 or 500.
4. **Self-hosting.** The network panel shows no font requests to any third-party origin; only the declared weights load; body and primary display weights are preloaded.
5. **Fallbacks and CLS.** Fallback `@font-face` rules with `size-adjust`/overrides are present for both families; measured layout shift from font swap is effectively zero.
6. **Resize and reflow (WCAG 1.4.4, 1.4.10).** All content and function are available at 200% text zoom and at 400% zoom / 320px width without horizontal scrolling or loss of content.
7. **Text spacing (WCAG 1.4.12).** Content passes the four text-spacing overrides in Section 7.2 with no clipping or overlap.
8. **Scaling honored.** Sizing is `rem`-based; the page remains usable with the browser's minimum font size raised and with OS large-text settings; the viewport meta does not disable zoom.

---

## Appendix — relationship to prior decisions

This specification records three digital decisions that extend the printed Brand Standards Guide, so they are not later "corrected" back to the guide's shorter statement:

1. **Poppins serves prominent interactive labels, not headlines alone.** Buttons, tabs, navigation, and disclosure headers use Poppins Bold — a deliberate digital extension of the guide's "Poppins for headlines," bounded by the 16px floor in Section 3.
2. **Two type scales exist** (Section 5): a larger content scale for reading and a tighter application scale for UI. The guide implies a single treatment; digital needs both.
3. **Link typography and colour** are specified in the Color Specification (deep blue, underlined, Roboto Medium), which the guide's "tertiary colours, used sparingly" language does not anticipate for a content-heavy site.

These, together with the button-typography and focus decisions already recorded, belong in a short digital addendum to the Brand Standards Guide.
