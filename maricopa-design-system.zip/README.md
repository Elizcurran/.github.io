# Maricopa County Digital Design System

A working library of accessible, brand-aligned components and prototypes built on the U.S. Web Design System (USWDS), themed to the Maricopa County brand.

## Publish on GitHub Pages

1. Create a new repository (public) and add every file in this bundle to the repository root.
2. Commit and push.
3. In the repository, go to **Settings → Pages**.
4. Under **Build and deployment → Source**, choose **Deploy from a branch**.
5. Set the branch to `main` and the folder to `/ (root)`, then **Save**.
6. Wait a minute or two; your site publishes at `https://<your-username>.github.io/<repo-name>/`.

`index.html` is the landing page and entry point. All pages are self-contained (styles and scripts are inline) and use relative links, so no build step or server is required.

## What's included

| File | What it is |
|---|---|
| `index.html` | Landing page linking everything below |
| `maricopa-components.html` | Component library — buttons, forms, alerts, tabs, accordion, in-page nav, anchors, process list, step indicator, modal, carousel, universal header & footer, token palette |
| `maricopa-example-page.html` | Full example service page showing the type hierarchy in a real layout |
| `maricopa-avatars.html` | Sonoran Desert profile avatar library (selectable) |
| `login.html` | Resident portal — sign-in screen (portal entry) |
| `overview.html` | Resident portal — account overview |
| `services.html` | Resident portal — My Services |
| `explore.html` | Resident portal — Explore Programs & Services |
| `support.html` | Resident portal — Support |
| `profile.html` | Resident portal — Profile & settings |
| `maricopa-portal.html` | The portal as a single self-contained file (alternative to the separate pages) |
| `maricopa-uswds-token-spec.md` | Token specification and vendor acceptance criteria |
| `maricopa-typography-spec.md` | Typography specification (font-pairing rules) |

## Notes

- **Fonts** load from the Google Fonts CDN for preview convenience. For production, self-host Poppins and Roboto (see the typography spec).
- **Logo and seal** appear as spelled-out placeholders ("County logo", "seal") where the official assets are dropped in.
- These are **prototypes**: the portal has no real authentication and its data resets on reload. Wiring to real accounts and data happens in the production build.
- The Markdown specifications render in GitHub's repository view. On the published Pages site they are linked as source files.
