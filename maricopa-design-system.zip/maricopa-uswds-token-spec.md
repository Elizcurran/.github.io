# Maricopa County Design System — Token Specification & Vendor Acceptance Criteria

**For:** Americaneagle.com (WordPress / Gutenberg implementation)
**From:** Office of Communications — Web & Creative Strategy
**Source of brand truth:** Maricopa County Brand Standards Guide, updated March 2026
**Source of component truth:** U.S. Web Design System (USWDS) 3.x
**Status:** Draft for vendor review

---

## 0. Purpose and how to use this document

This document defines the design tokens, component scope, editorial guardrails, and acceptance criteria for the Maricopa County WordPress implementation. It is intended to be attached to or referenced by the statement of work.

Sections 1 through 4 are **specification** — values that must be implemented as written. Section 5 defines **scope**. Sections 6 and 7 define **acceptance criteria** and are the basis on which deliverables will be accepted or rejected.

Every contrast ratio in this document has been calculated against the WCAG 2.1 relative luminance formula and is stated to two decimal places. Where a value is marked FAIL, it is not a matter of preference.

---

## 1. Architectural directive

**USWDS 3.x shall be installed and configured as a declared project dependency.** Maricopa branding shall be applied through USWDS Sass theme settings, not by reimplementing USWDS components as bespoke code.

This is a requirement, not a preference. The rationale is maintenance liability: GSA maintains the keyboard interaction, focus management, and screen-reader behavior of the complex components (accordion, combo box, date picker, modal, in-page navigation, banner, header). A visual lookalike transfers permanent ownership of those defects to Maricopa County. With the ADA Title II compliance date of **April 2027**, the County is not in a position to absorb that.

Specific requirements:

1. USWDS shall be installed via npm at a **named, pinned version**, stated in the deliverable documentation.
2. Branding shall be applied via the USWDS theme settings files (`_uswds-theme-color.scss`, `_uswds-theme-typography.scss`, `_uswds-theme-spacing.scss`, and related). Component Sass shall not be forked.
3. **USWDS Elements** (the Web Component version, sometimes called USWDS 4) shall **not** be used. It remains in pre-release with components at varying maturity. USWDS Core 3.x is the target.
4. The vendor shall document an upgrade path and state what is required to move to the next USWDS minor version.
5. Any deviation from stock USWDS markup shall be documented, with a stated reason and an accessibility impact assessment.

---

## 2. Color tokens

### 2.1 Verified contrast reference

All ratios computed against `#FFFFFF` unless noted. **AA body text requires 4.5:1. Large text (≥24px, or ≥18.66px bold) and non-text UI elements require 3:1.**

| Brand name | Hex | vs. white | Permitted use on white |
|---|---|---|---|
| Summer Night Blue | `#132048` | **15.81:1** | Any text, any size. Surfaces, borders, focus. |
| Summer Night Blue 75% | `#424466` | **9.33:1** | Any text, any size. |
| Summer Night Blue 50% | `#716F89` | **4.84:1** | Body text (thin margin — see note) |
| Summer Night Blue 25% | `#AAA8BA` | 2.33:1 | Non-text decoration only |
| Sunrise Orange | `#F26724` | **3.12:1** | **Large text and UI elements only — NOT body text** |
| Sunrise Orange 75% | `#F58B56` | 2.41:1 | Non-text decoration only |
| Sunrise Orange 50% | `#F9AD84` | 1.85:1 | Non-text decoration only |
| Sunrise Orange 25% | `#FCD4BB` | 1.37:1 | Surface fill only |
| Desert Turquoise | `#1E988A` | **3.55:1** | **Large text and UI elements only — NOT body text** |
| Desert Turquoise 60% | `#68ABA1` | 2.65:1 | Non-text decoration only |
| Desert Turquoise 40% | `#98C1BB` | 1.97:1 | Non-text decoration only |
| Desert Turquoise 20% | `#C8DBD8` | 1.44:1 | Surface fill only |
| Monsoon Grey | `#D8DFE1` | 1.35:1 | Surface fill, borders |
| Monsoon Grey 75% | `#E1E6E7` | 1.26:1 | Surface fill |
| Monsoon Grey 50% | `#EAEDED` | 1.18:1 | Surface fill |
| Monsoon Grey 25% | `#F3F4F4` | 1.10:1 | Surface fill |
| Sunshine Yellow | `#FAA21B` | 2.05:1 | **Non-text only. Never text on light surfaces.** |
| Sunshine Yellow 75% | `#FBB658` | 1.76:1 | Non-text decoration only |
| Sunshine Yellow 50% | `#FDCD8B` | 1.47:1 | Surface fill only |
| Sunshine Yellow 25% | `#FFE4C0` | 1.23:1 | Surface fill only |
| Sky Blue | `#0070B9` | **5.23:1** | Any text. **Designated link color.** |
| Sky Blue 75% | `#5588C6` | 3.67:1 | Large text and UI elements only |
| Sky Blue 50% | `#89A6D6` | 2.47:1 | Non-text decoration only |
| Sky Blue 25% | `#BFCDE9` | 1.60:1 | Surface fill only |
| Night Black | `#131D28` | **17.02:1** | Any text. Primary body text color. |
| Night Black 75% | `#3E414A` | **10.20:1** | Any text. |
| Night Black 50% | `#6D6D75` | **5.13:1** | Body text. Secondary/meta text. |
| Night Black 25% | `#AAA8AE` | 2.35:1 | Borders, disabled states, non-text only |

**Note on `#716F89` (Summer Night Blue 50%):** at 4.84:1 it passes, but the margin is 0.34. Any future adjustment to the surface it sits on will break it. Do not use it on any surface other than pure white.

### 2.2 The critical finding: primary buttons

The intuitive brand-forward choice — a Sunrise Orange button with a white label — **fails WCAG AA.**

| Combination | Ratio | Verdict |
|---|---|---|
| White on Sunrise Orange `#F26724` | **3.12:1** | **FAIL** for button labels |
| Night Black `#131D28` on Sunrise Orange | **5.46:1** | PASS |
| Summer Night Blue `#132048` on Sunrise Orange | **5.08:1** | PASS |
| White on Summer Night Blue `#132048` | **15.81:1** | PASS |
| White on Sky Blue `#0070B9` | **5.23:1** | PASS |
| White on Desert Turquoise `#1E988A` | 3.55:1 | **FAIL** for button labels |
| Night Black on Sunshine Yellow `#FAA21B` | **8.30:1** | PASS |

Button labels are normal-size text and are held to 4.5:1. There is no large-text exemption.

**Specification — primary button:** Summer Night Blue `#132048` fill, white label, 15.81:1. This is the safest option and survives any future surface change.

**If Sunrise Orange is required as the primary action color** as a brand decision, it must be paired with a **Night Black `#131D28` label at 5.46:1**. Dark text on orange is visually unusual for a CTA and should be reviewed by Communications before implementation. It is conformant; it is not conventional.

Sunrise Orange remains fully available at 3.12:1 for: large display headings (≥24px), icons, rules and dividers, borders, chart fills, and non-text accents. This is where it should carry the brand.

### 2.3 Links

Sky Blue `#0070B9` is the designated link color at **5.23:1** on white. This aligns with the existing brand guide, which assigns tertiary colors to hyperlinks.

**Caution:** on a Monsoon Grey 25% surface (`#F3F4F4`), Sky Blue drops to **4.74:1**. It still passes, but by 0.24. On any Monsoon Grey surface darker than 25%, links must switch to Summer Night Blue `#132048` (14.35:1 on `#F3F4F4`).

Link underlines shall be retained. Color alone shall not distinguish links from body text (WCAG 1.4.1).

**Governance note for Communications:** the brand guide directs that tertiary colors be used "sparingly for smaller pieces of information such as web site hyperlinks." On a content-heavy county website, links are not sparing — they are pervasive. Sky Blue will become one of the most-used colors on maricopa.gov. This is the correct accessibility outcome but it is in tension with the guide's stated intent, and warrants a short digital addendum to the brand standards rather than a silent departure from them.

### 2.4 Neutral ramp construction

The brand palette has **no mid-tone neutrals.** Monsoon Grey spans only 1.10:1 to 1.35:1 — all four tints are near-white. USWDS requires a full base ramp from near-white to near-black for text, borders, surfaces, and disabled states.

**Construct the neutral ramp by combining Night Black and Monsoon Grey:**

| USWDS role | Hex | Brand source | vs. white |
|---|---|---|---|
| base-lightest | `#F3F4F4` | Monsoon Grey 25% | 1.10:1 |
| base-lighter | `#EAEDED` | Monsoon Grey 50% | 1.18:1 |
| base-light | `#D8DFE1` | Monsoon Grey 100% | 1.35:1 |
| base | `#AAA8AE` | Night Black 25% | 2.35:1 |
| base-dark | `#6D6D75` | Night Black 50% | 5.13:1 |
| base-darker | `#3E414A` | Night Black 75% | 10.20:1 |
| base-darkest | `#131D28` | Night Black 100% | 17.02:1 |
| ink (body text) | `#131D28` | Night Black 100% | 17.02:1 |

There is a perceptual gap between `#AAA8AE` (2.35:1) and `#D8DFE1` (1.35:1) with nothing in between. If AEG needs an intermediate step for borders or table rules, it shall be proposed to Communications for approval as a brand extension rather than invented in code.

### 2.5 Semantic and state colors — do not rebrand

**USWDS default error, warning, success, and info colors shall be retained unmodified.**

Do not substitute brand colors for system states. Specifically:

- **Sunshine Yellow shall not be used as a warning color.** At 2.05:1 it fails on light surfaces and cannot carry warning text.
- **Desert Turquoise shall not be used as a success color.** At 3.55:1 it fails for body text.
- **Sunrise Orange shall not be used as an error or alert color.** It fails at 3.12:1 for text and, separately, orange carries no reliable danger semantics.

State colors are functional, not decorative. USWDS has already validated its defaults for contrast and for use alongside icons and text labels (satisfying WCAG 1.4.1, which prohibits conveying information by color alone).

### 2.6 Indicative USWDS theme settings

Exact variable naming shall be confirmed against the USWDS 3.x settings documentation for the pinned version.

```scss
// _uswds-theme-color.scss

$theme-color-primary:            #132048;  // Summer Night Blue
$theme-color-primary-darker:     #0B1430;  // derive; must exceed 15:1 on white
$theme-color-primary-light:      #424466;  // Summer Night Blue 75%
$theme-color-primary-lighter:    #AAA8BA;  // non-text use only
$theme-color-primary-lightest:   #F3F4F4;

$theme-color-accent-warm:        #F26724;  // Sunrise Orange — see 2.2 label rule
$theme-color-accent-cool:        #0070B9;  // Sky Blue — link and cool accent

$theme-color-base:               #6D6D75;
$theme-color-base-dark:          #3E414A;
$theme-color-base-darkest:       #131D28;
$theme-color-base-light:         #AAA8AE;
$theme-color-base-lighter:       #D8DFE1;
$theme-color-base-lightest:      #F3F4F4;

$theme-color-error:              // USWDS default — DO NOT OVERRIDE
$theme-color-warning:            // USWDS default — DO NOT OVERRIDE
$theme-color-success:            // USWDS default — DO NOT OVERRIDE
$theme-color-info:               // USWDS default — DO NOT OVERRIDE
```

Derived values (such as `primary-darker`) shall be submitted with measured contrast ratios, not chosen by eye.

---

## 3. Typography

Brand fonts are **Poppins** (headlines) and **Roboto** (subheadings, body, links).

| Role | Family | Weight | Brand guide reference |
|---|---|---|---|
| Display / headlines | Poppins | ExtraBold (800) | "Poppins Extra Bold (Headlines)" |
| Subheadings | Roboto | Bold (700) | "Roboto Bold (Subheadings)" |
| Body copy | Roboto | Regular (400) | "Roboto Regular (Body Copy)" |
| Links | Roboto | Bold (700) | "Roboto Bold (Links)" |

Requirements:

1. USWDS shall be configured with Poppins and Roboto registered as custom typefaces via the typography settings file. Public Sans and Merriweather shall not appear in the compiled output.
2. **Fonts shall be self-hosted.** Do not load from the Google Fonts CDN. Both families are openly licensed and redistributable; self-hosting removes a third-party request from every county page load and avoids sending resident IP addresses to a third party. Confirm the license terms are satisfied and retain the license files in the repository.
3. `font-display: swap` shall be set, with a metric-compatible fallback stack declared to limit layout shift.
4. **The USWDS type scale shall be retained.** Do not replace USWDS's modular scale with arbitrary pixel values. Brand fonts change the typeface, not the scale.
5. Body text shall not be set below 16px. Poppins ExtraBold is a display weight and shall not be applied to body copy or to any text below 24px.
6. Line-height and paragraph spacing shall satisfy WCAG 1.4.12 (Text Spacing): content must remain functional when line height is set to 1.5× font size, paragraph spacing to 2× font size, letter spacing to 0.12em, and word spacing to 0.16em.

**Note:** Roboto Bold is specified for links. Bold plus underline plus Sky Blue is a strong treatment at body size. Communications should review a rendered sample before this is locked, as it may read as heavier than intended in long-form content.

---

## 4. Focus and interaction states

Focus visibility is among the most commonly failed criteria in ADA Title II remediation and shall be treated as a first-class requirement.

1. **Focus indicators shall never be removed.** `outline: none` without an equivalent replacement is grounds for rejection.
2. **Focus ring on light surfaces: Summer Night Blue `#132048`** — 15.81:1 against white, far exceeding the 3:1 minimum for non-text contrast.
3. **Focus ring on dark surfaces (Summer Night Blue fills): Sunshine Yellow `#FAA21B`** — 7.72:1 against `#132048`.
4. **Sunshine Yellow shall not be used as a focus ring on white or light surfaces.** At 2.05:1 it fails the 3:1 non-text contrast requirement. This is a likely default choice because USWDS ships a gold focus ring and Sunshine Yellow resembles it. It is not equivalent.
5. Focus ring width shall be no less than 2px with a visible offset.
6. Hover, active, visited, and disabled states shall each be specified and tested. Disabled controls shall not rely on `#AAA8AE` text alone to communicate state.
7. Keyboard focus order shall follow visual reading order on every template.

---

## 5. Component scope

### 5.1 Excluded — federal-only components

The following USWDS components are specific to federal agencies and **shall not be implemented** on maricopa.gov:

| Component | Reason |
|---|---|
| **Banner** | The "An official website of the United States government" identification strip. Maricopa County is a county government. Implementing this would be factually incorrect. |
| **Identifier** | Displays parent-agency links required by federal law and policy. No county equivalent obligation exists. |

If a county-level trust or identification element is desired, it shall be designed as a new component and specified separately. It shall not be a relabeled federal Banner.

### 5.2 Known gaps in the USWDS design kit

The USWDS Figma design kit documents these gaps. AEG shall state how each is addressed:

| Gap | Status in USWDS | Required response |
|---|---|---|
| **Grid** | Not included in the design kit | Specify the layout system to be used and how it maps to Gutenberg layout blocks |
| **Form** | Not a standalone component; built from individual inputs | Specify form composition patterns and validation behavior |
| **Data visualization** | Not included | Specify approach, including accessible alternatives (data tables) for every chart |
| **Validation** | Not published; slated for deprecation | Do not implement. Specify the replacement approach for inline validation messaging. |

Charts require particular attention: the secondary palette is designated in the brand guide for charts and infographics, but Desert Turquoise, Sunshine Yellow, and their tints fail text contrast. Chart labels shall use Night Black or Summer Night Blue, and data series shall be distinguished by pattern, label, or shape in addition to color.

### 5.3 Priority components

Scope shall be driven by an audit of what maricopa.gov actually uses rather than by implementing the full USWDS catalog. AEG shall propose a phased list for Communications approval. Components with complex interaction behavior — accordion, combo box, date picker, modal, in-page navigation, side navigation, header, pagination, tooltip — shall use stock USWDS JavaScript.

---

## 6. Editorial guardrails — `theme.json`

Full Site Editing gives content editors the ability to produce non-conformant pages without writing any code. Given the number of county departments publishing to maricopa.gov, this is the single largest ongoing compliance risk in the project. The guardrails are a deliverable, not a configuration detail.

Required `theme.json` settings:

| Setting | Value | Reason |
|---|---|---|
| `settings.color.custom` | `false` | Prevents arbitrary hex entry by editors |
| `settings.color.customGradient` | `false` | Gradients cannot be contrast-verified |
| `settings.color.defaultPalette` | `false` | Removes the WordPress core palette |
| `settings.color.defaultGradients` | `false` | Removes core gradients |
| `settings.color.palette` | Approved tokens only | Editors select from verified values |
| `settings.typography.customFontSize` | `false` | Prevents sub-16px body text |
| `settings.typography.fontSizes` | USWDS scale only | Preserves the modular scale |
| `settings.typography.fontFamilies` | Poppins, Roboto only | Prevents off-brand typefaces |
| `settings.spacing.customSpacingSize` | `false` | Preserves the USWDS spacing scale |
| `settings.layout` | Fixed content and wide widths | Prevents line lengths that harm readability |

Additional requirements:

1. **Color palette entries shall be named for their role, not their appearance** — "Primary Action," "Link," "Body Text," "Surface Subtle" rather than "Blue," "Orange," "Grey." Editors choose correctly far more often when the name states the purpose.
2. **Any palette entry that fails 4.5:1 on the default surface shall not be exposed as a text color option at all.** Sunshine Yellow, Desert Turquoise, and the light tints shall be available as background and accent options only. If the block editor cannot enforce this separation, it shall be documented as a residual risk.
3. **Block patterns shall be locked** (`templateLock`) where the pattern encodes an accessibility-relevant structure, such as heading hierarchy or landmark regions.
4. **Heading levels shall not be freely selectable** in patterns where hierarchy matters. Skipped heading levels are among the most common findings in county-level audits.
5. A **pattern library** shall be delivered covering the county's recurring page types, so editors assemble approved compositions rather than building layouts freehand.

---

## 7. Acceptance criteria

Deliverables will be evaluated against the following. A general attestation of "WCAG 2.1 AA compliant" is not sufficient evidence and will not be accepted on its own.

### 7.1 Per-component evidence

For each delivered component, AEG shall provide:

1. **Keyboard operation test results** — all functionality operable without a mouse, no keyboard traps, logical focus order, visible focus at every step.
2. **Screen reader test results** — tested on at least two combinations, one of which shall be NVDA or JAWS with Windows, and one VoiceOver with Safari. Named versions shall be stated.
3. **Measured contrast ratios** for every text and non-text pairing in every state, including hover, focus, active, and disabled.
4. **Zoom and reflow verification** — usable at 400% zoom at 320px width without horizontal scrolling (WCAG 1.4.10).
5. **Text spacing verification** per WCAG 1.4.12.

### 7.2 Automated testing

Automated scanning shall be run against every template and every delivered pattern. The County uses **Silktide**; AEG shall provide results from an automated tool and shall remediate all identified issues. Automated testing is a floor, not a ceiling — a clean automated scan does not by itself constitute acceptance, since automated tools detect a minority of WCAG failures.

### 7.3 Remediation obligation

Accessibility defects identified within the warranty period shall be remediated at vendor cost. The definition of defect shall include any failure of WCAG 2.1 Level A or AA, not only defects that automated tooling detects. This shall be explicit in the SOW.

### 7.4 Documentation and handover

1. Complete token documentation as implemented, with the mapping from brand name to USWDS token to CSS custom property.
2. Pinned USWDS version and stated upgrade path.
3. Editor-facing guidance on the pattern library and the constraints in Section 6.
4. **All design source files delivered to Maricopa County at project close**, including the working Figma file, in a form the County can edit and maintain without further vendor engagement.

---

## Appendix A — Issues found in the Brand Standards Guide

These were identified while preparing this specification and are for the Office of Communications, not for AEG.

1. **Desert Turquoise 40% tint has an incorrect hex value.** The guide lists RGB `152, 193, 187` alongside hex `#C8DBD8`. Those do not correspond — `#C8DBD8` is RGB `200, 219, 216`, which is the 20% tint. The RGB values imply the correct hex is `#98C1BB`. As published, the 40% and 20% tints are identical, and any designer working from hex will produce a four-step ramp with only three visible steps. This specification uses `#98C1BB`, derived from the stated RGB. **Recommend correcting the published guide.**

2. **Tertiary color guidance conflicts with web use.** See Section 2.3. Sky Blue is the only link-conformant brand color, which makes it unavoidably prominent on a content-heavy site, contrary to the "used sparingly" direction.

3. **No mid-tone neutrals exist in the palette.** See Section 2.4. The Night Black and Monsoon Grey ramps must be combined to produce a usable interface neutral scale, and a gap remains between 2.35:1 and 1.35:1.

4. **The palette has no designated state colors.** This specification directs that USWDS defaults be retained. If Communications wants branded state colors in future, they must be designed against contrast requirements from the outset rather than selected from the existing palette.

5. **Minor:** a character encoding artifact appears in the online tertiary palette section ("de□ned" for "defined"), likely from PDF-to-web conversion.
